# Toronto ProcesseS (TPS)

A simple process reporting tool

## Building

    meson setup build
    meson compile -C build

## Testing

    meson test -C build
